declare module 'userType' {
  export interface UserType {
    username: string;
    password: string;
  }
}
